冒險島 · v0.4 美術與即時換裝正式整合版
2026-11-10（Asia/Taipei）

解壓後開啟 game/index.html 即可單機遊玩；所有正式資產均內嵌或程序繪製，不需安裝套件或架設服務。
冒險中右側整理裝備／查看素質，戰鬥繼續；G展開、Escape收合。
掉落不會自動重排正在比較的背包，按「更新背包」顯示新到貨。
換裝使用原公式；非升級時HP／MP不免費補滿。
若換檔案位置後瀏覽器使用不同存檔來源，可由原版設定匯出，再用新版既有匯入功能。

前後對照：docs/reviews/implementation/COMPARISON.html
完整驗證與剩餘界線：docs/reviews/implementation/VALIDATION.md
完整來源／工具／歷史：https://github.com/LoHAs-hub/Adventure-Island/tree/work

核心正式測試、雙分頁同步、存檔比對及資料聯絡表已通過；仍未完整驗證外網WebRTC、逐攻擊幀／逐招碰撞與全部強化邊界、所有歷史實檔／匯入匯出UI及跨設備長時間效能。
managed Chrome禁止file://，本輪以完全離線載入相同HTML驗證單檔依賴，未宣稱直接file://已測。
這份封裝不包含任何玩家或測試存檔。MANIFEST.json供選用的SHA-256核對。
