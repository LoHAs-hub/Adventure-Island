冒險島 · v0.4 本輪重做版

解壓後開啟 game/index.html 單機遊玩；無需安裝套件。原始遊戲資料與玩法保留。
自動戰鬥中可從右側比較、鎖定、整理與換裝，能力立即套用；HP/MP不因換裝免費補滿。
新到貨按「更新」才加入目前背包排列。G展開管理；焦點在管理區時Escape收合，戰場Escape/P為原暫停。
連線兩端請使用同版；戰鬥中可整理／養成，轉蛋於大廳使用。
若檔案位置造成不同瀏覽器存檔來源，先從原版設定匯出，再在新版設定匯入。

前後對照：docs/reviews/redo/COMPARISON.html（或COMPARISON.png）
驗證與未驗證項目：docs/reviews/redo/VALIDATION.md
跨聊天室接手：START-HERE.md
來源／每檔SHA：MANIFEST.json；本包不含玩家或測試存檔。

外網WebRTC、跨設備長時間與背景休眠、全部歷史實檔／交叉組合未完整驗證。
相同HTML完全離線、零外部請求已驗證；managed Chrome阻擋直接fileURL，未宣稱該路徑實測。
前次d1942ae未通過使用者驗收；本包直接從重新上傳的原始遊戲重做，不沿用其實作。
