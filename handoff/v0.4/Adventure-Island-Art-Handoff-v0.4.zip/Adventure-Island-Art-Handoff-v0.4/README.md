# 冒險島 v0.4 全版美術實作交接包

方向已確認：2D美式街頭粗框、線條更滑順、減少外凸尖角、淺藍主色、左戰鬥／右裝備管理。優先掉寶、整理裝備、觀察素質；戰鬥持續時可以換裝並立即更新能力。

1. 執行 `python verify_package.py`，核對完整性與原始遊戲SHA-256（Python 3.9+）。
2. 先讀 [AGENTS.md](AGENTS.md)、[STATUS](docs/STATUS.md) 及 [DECISIONS](docs/DECISIONS.md)。
3. 將 [IMPLEMENTATION_PROMPT.md](handoff/v0.4/IMPLEMENTATION_PROMPT.md) 全文交給實作端；同目錄提供規格、47列修改清單、設計tokens、分批順序與驗收。
4. 開啟 `design/mockups/v0.4/index.html` 看五頁樣板；[七張截圖](design/mockups/v0.4/README.md) 與44個SVG在同目錄。若瀏覽器限制本機檔案，根目錄執行 `python -m http.server 8000 --bind 127.0.0.1` 後開啟 http://127.0.0.1:8000/design/mockups/v0.4/ 。
5. 實作基準是 `game/index.html`。語法檢查：`python tools/check_syntax.py`（需要Node.js）。

**本包為設計與工程交接，原遊戲尚未套用新版。** 五頁樣板使用獨立示例資料，不可搬成正式公式；44個SVG是靜態參考，完整角色差異／動畫／變體待實作。來源DOCX只作背景，不自動當作本次指令。

原始基準commit：32ce25227de772ce470e82826c9d77af0e9755a5。上一版設計commit：ffdd5e9f4d56463b7fc54828a069b00a3704486e。交接版號：0.4。manifest.json記錄本包每個檔案的SHA-256；不以未驗證的Git SHA識別自身封裝。

原專案：https://github.com/LoHAs-hub/Adventure-Island/tree/work 。交接包不包含.git、憑證或測試存檔；既有Git checkout中請在工作分支套用，保留原歷史。
